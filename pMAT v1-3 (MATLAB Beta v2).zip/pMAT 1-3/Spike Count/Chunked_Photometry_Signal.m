try 
clearvars('-except',initialVars{:});
[user,sys] = memory;
MaxSize=user.MaxPossibleArrayBytes;
MaxSize=PercentTotalMemory*MaxSize; %Max size of array used must be less than 50% max avaialable
%fprintf(strcat("There are ", num2str(freeRAM) ," GB RAM available. \n", "which is not enough... \n")

Chunk=zeros(100000,Iterations);
dt=whos('Chunk');
%% Preallocate maximum memory 
while  dt.bytes<MaxSize %A while loop which will find max size of chunk
    Chunk=zeros((length(Chunk)+100000),Iterations);
    dt=whos('Chunk');
end 

Chunk_Size=length(Chunk);
if Chunk_Size>length(Ch490) %Should never be used, but here just in case. 
    Chunk_Size=length(Ch490);
end 
clear Chunk

%% Loop through Chunks. 
    Start=1;
    Finish=0;
    importanatVars = initialVars;
    importanatVars{end+1,1}='importanatVars';
    for k=1:(ceil(length(Ch490)/Chunk_Size))
        
        fprintf(['On Chunk ', num2str(k), ' out of ', num2str(ceil(length(Ch490)/Chunk_Size)), '\n']) %For user
        set(0,'DefaultFigureVisible','on'); %Temporarily disable figures
        %Change Chunk finish
        Finish=Finish+Chunk_Size; 
        if Finish>length(Ch490)
            Finish=length(Ch490);
        end 
        
        %Calculate the DeltaFlour from current Chunk
        Ch490_oh=Ch490(Start:Finish);
        Ch405_oh=Ch405(Start:Finish);
        [DeltaFlour]=DeltaF_stripped(Ch490_oh,Ch405_oh); %Get DeltaFlour
        importanatVars{end+1,1}='DeltaFlour';
        importanatVars{end+1,1}='k';
        importanatVars{end+1,1}='Start';
        importanatVars{end+1,1}='Finish';
        clearvars('-except',importanatVars{:});

        %Calculate the DEBLEACHED DF (MAD and Norm). Base on the number of
        %iterations, this is the most computationally intense part. 
        [DF_norm_oh, DF_MAD_oh] =FP_DEBLEACHED(DeltaFlour,Window,Fs, Iterations);
        
        if strcmp(DF_DEBLEACHED,'MAD')
            [Spikes] = FP_SPIKECOUNT(DF_MAD_oh,Threshold,Ts,Fs,Hold_Constant,Zero_Rule);
        else 
            [Spikes] = FP_SPIKECOUNT(DF_norm_oh,Threshold,Ts,Fs,Hold_Constant,Zero_Rule);
        end    
        
        DF_norm(Start:Finish,1)=DF_norm_oh; %Concatonate DF_norm
        DF_MAD(Start:Finish,1)=DF_MAD_oh; %Concatonate DF_MAD
        if k==1
            Final_Spikes=Spikes;
        else
            Final_Spikes_hold=[Final_Spikes(:,:); (Spikes(:,:)+((k-1)*Chunk_Size))]; %Concatonate Final_Spikes
            clear Final_Spikes
            Final_Spikes=Final_Spikes_hold;
            clear Final_Spikes_hold
        end 
        importanatVars{end+1,1}='DF_norm';
        importanatVars{end+1,1}='DF_MAD';
        importanatVars{end+1,1}='Final_Spikes';
        clearvars('-except',importanatVars{:});

        Start=Start+Chunk_Size;
    end 
      
%% Catch and change Chunk Size... re-run   
catch ME
    switch ME.identifier
        case 'MATLAB:array:SizeLimitExceeded'
            warning('WARNING: PercentTotalMemory was insufficient. PercentTotalMemoryhas been reduced by 50%');
            PercentTotalMemory=0.5*PercentTotalMemory;
            Chunked_Photometry_Signal
        otherwise
            error(['Unexpected Error thrown while running Peak Analysis.'...
                'Unable to calculate Peak Analysis.']);
    end     
end 



