%% By David Estrin & David Barker for the Barker Laboratory
% Code is written for Bruno C. et al., 2020
% The purpose of this code is to take a calcium trace from fiber
% photometry and detrend/debleach the trace.

%% DISCLAIMER
% Our spike counter will count spikes but is not resilient to poor/no
% signal animals. Please be causious when running animals through spike
% code. We suggest a threshold of 2:1 Signal:Noise. Also, we suggest users
% inspect individual transients and look for a fast rise/ slow decay. 

%% CLEAR EVERYTHING & SET UP
restoredefaultpath %Remove all extra paths
clear all; close all; clc; %Clear All
addpath('D:\RESEARCH_DATA\BARKER_LAB\PHOTOMETRY_SPIKE_COUNT_FUNCTIONS_AND_SCRIPTS'); 
PREVIOUS_CODE_SCRIPT; % Code from Barker et al., 2017

%% The following are User Defined Variables
% 1--Iterations   see FP_DEBLEACHED.m
% 2--Window       see FP_DEBLEACHED.m
% 3--DF_DEBLEACHED   see FP_SPIKECOUNT.m
% 4--Threshold       see FP_SPIKECOUNT.m
% 5--Hold_Constant   see FP_SPIKECOUNT.m
% 6--Zero_Rule       see FP_SPIKECOUNT.m
% 7--PercentTotalMemory see Chunked_Photometry_Signal.m


Iterations = 100; % Number of iterations 
Window = 15; % A 15 second window. 
DF_DEBLEACHED = 'MAD'; % Set to 'MAD' or 'NORM'
Threshold = 2.91; % Our choice for threshold 
Hold_Constant =1; % >0 ; time in seconds
Zero_Rule = 1; % 1 or 0 ; Yes or No

PercentTotalMemory=0.5; % Is not user defined... 
initialVars = who; %Esential variables
initialVars{end+1,1}='initialVars';
try 
[DeltaFlour]=DeltaF_stripped(Ch490,Ch405); %Get DeltaFlour
importanatVars = initialVars;
importanatVars{end+1,1}='DeltaFlour';
clearvars('-except',importanatVars{:});

%% Calipari Calculation 
% This is a typical example from the literature. Taken from Calipari et al.,2016
% DF_DT=detrend(DeltaFlour);
% mad_DT=mad(DF_DT);
% std_DT=std(DF_DT); %Add this
% DF_DT_MAD=DF_DT./mad_DT;
% DF_DT_MAD(:,2)=Ts;
% DF_DT_MAD_spikes=(DF_DT_MAD>2.91);
% figure('units','normalized','outerposition',[0 0 1 1]);
% set(gcf,'color','w');
% plot(DF_DT_MAD(:,2),DF_DT_MAD(:,1), 'LineWidth',2)
% hold on
% plot([0 length(DF_DT_MAD)],[2.91 2.91],'--k','LineWidth',2)
% xlim([0 (length(DF_DT_MAD(:,1)))./Fs])
% set(gca,'box','off');
% xlabel('TIME (seconds)');
% ylabel('Normalized dF/F');
% set(findall(gcf,'-property','FontSize'),'FontSize',18)

%% De-Bleach and Count Spikes
[DF_norm, DF_MAD] =FP_DEBLEACHED(DeltaFlour,Window,Fs, Iterations);

    if strcmp(DF_DEBLEACHED,'MAD')
        [Spike_Values] = FP_SPIKECOUNT (DF_MAD,Threshold,Ts,Fs,Hold_Constant,Zero_Rule);
    else 
        [Spike_Values] = FP_SPIKECOUNT (DF_norm,Threshold,Ts,Fs, Hold_Constant,Zero_Rule);
    end 
    
catch ME %% Navigate Errors...
    switch ME.identifier
        case 'MATLAB:array:SizeLimitExceeded'
             fprintf(['The current photometry trace \nhas been identified as too large \n'...
                 'The trace will be run in batches (AKA chunks) \n']);
             Chunked_Photometry_Signal; % Run Data in Chunks
        otherwise
             warning(['Unexpected Error thrown while running Peak Analysis.'...
                'Unable to calculate Peak Analysis.']);
                rethrow(ME) % Keep rethrowing the error until time out. 
    end 
end 

 







